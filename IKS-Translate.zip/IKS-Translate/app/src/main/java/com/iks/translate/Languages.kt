package com.iks.translate

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

enum class Script { LATIN, CHINESE, JAPANESE, KOREAN }

data class Lang(val name: String, val code: String, val script: Script) {
    override fun toString() = name
}

object Languages {
    val all = listOf(
        Lang("Indonesia", TranslateLanguage.INDONESIAN, Script.LATIN),
        Lang("Inggris", TranslateLanguage.ENGLISH, Script.LATIN),
        Lang("Jepang", TranslateLanguage.JAPANESE, Script.JAPANESE),
        Lang("Korea", TranslateLanguage.KOREAN, Script.KOREAN),
        Lang("Mandarin", TranslateLanguage.CHINESE, Script.CHINESE),
        Lang("Spanyol", TranslateLanguage.SPANISH, Script.LATIN),
        Lang("Prancis", TranslateLanguage.FRENCH, Script.LATIN),
        Lang("Jerman", TranslateLanguage.GERMAN, Script.LATIN),
        Lang("Portugis", TranslateLanguage.PORTUGUESE, Script.LATIN),
        Lang("Belanda", TranslateLanguage.DUTCH, Script.LATIN),
    )

    fun byCode(code: String?): Lang = all.firstOrNull { it.code == code } ?: all[1]

    fun recognizer(script: Script): TextRecognizer = when (script) {
        Script.LATIN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        Script.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        Script.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        Script.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    }
}
