package com.iks.translate

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

/** Menggambar hasil terjemahan tepat di atas posisi teks aslinya. */
class TranslationOverlayView(context: Context) : View(context) {

    data class Item(val rect: Rect, val text: String)

    var items: List<Item> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    private val density = resources.displayMetrics.density
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF0151C26.toInt() }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        val pad = 4 * density
        val minSize = 10 * density
        val maxSize = 28 * density

        for (item in items) {
            val width = maxOf(item.rect.width() - 2 * pad, 24 * density).toInt()
            var size = minOf(item.rect.height() * 0.7f, maxSize).coerceAtLeast(minSize)
            var layout = buildLayout(item.text, size, width)
            while (layout.height > item.rect.height() - pad && size > minSize) {
                size -= 1f
                layout = buildLayout(item.text, size, width)
            }
            // Jika masih terlalu tinggi, kotak diperbesar ke bawah agar teks tetap terbaca.
            val bottom = maxOf(item.rect.bottom.toFloat(), item.rect.top + layout.height + 2 * pad)
            canvas.drawRoundRect(
                RectF(item.rect.left.toFloat(), item.rect.top.toFloat(), item.rect.left + width + 2 * pad, bottom),
                6 * density, 6 * density, bgPaint
            )
            canvas.save()
            canvas.translate(item.rect.left + pad, item.rect.top + pad)
            layout.draw(canvas)
            canvas.restore()
        }
    }

    private fun buildLayout(text: String, size: Float, width: Int): StaticLayout {
        textPaint.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .build()
    }
}
