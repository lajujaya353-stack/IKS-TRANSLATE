package com.iks.translate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : AppCompatActivity() {

    private lateinit var spSource: Spinner
    private lateinit var spTarget: Spinner
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { downloadThenCapture() }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_START)
                    .putExtra(ScreenTranslateService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(ScreenTranslateService.EXTRA_DATA, data)
                    .putExtra(ScreenTranslateService.EXTRA_SRC, (spSource.selectedItem as Lang).code)
                    .putExtra(ScreenTranslateService.EXTRA_TGT, (spTarget.selectedItem as Lang).code)
                ContextCompat.startForegroundService(this, intent)
                tvStatus.setText(R.string.status_running)
                moveTaskToBack(true)
            } else {
                tvStatus.setText(R.string.status_denied)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spSource = findViewById(R.id.spSource)
        spTarget = findViewById(R.id.spTarget)
        btnStart = findViewById(R.id.btnStart)
        tvStatus = findViewById(R.id.tvStatus)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Languages.all)
        spSource.adapter = adapter
        spTarget.adapter = adapter
        spSource.setSelection(1) // Inggris
        spTarget.setSelection(0) // Indonesia

        btnStart.setOnClickListener { onStartClicked() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, ScreenTranslateService::class.java))
            tvStatus.setText(R.string.status_idle)
        }
    }

    private fun onStartClicked() {
        if ((spSource.selectedItem as Lang).code == (spTarget.selectedItem as Lang).code) {
            Toast.makeText(this, R.string.err_same_lang, Toast.LENGTH_SHORT).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        downloadThenCapture()
    }

    /** Unduh model terjemahan (sekali saja, ±30 MB per bahasa), lalu minta izin rekam layar. */
    private fun downloadThenCapture() {
        val src = spSource.selectedItem as Lang
        val tgt = spTarget.selectedItem as Lang
        lifecycleScope.launch {
            btnStart.isEnabled = false
            tvStatus.setText(R.string.status_downloading)
            val translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src.code)
                    .setTargetLanguage(tgt.code)
                    .build()
            )
            try {
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                tvStatus.setText(R.string.status_ready)
                val mpm = getSystemService(MediaProjectionManager::class.java)
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            } catch (e: Exception) {
                tvStatus.text = getString(R.string.err_download, e.message ?: "")
            } finally {
                translator.close()
                btnStart.isEnabled = true
            }
        }
    }
}
