package com.iks.translate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Service latar depan: menangkap layar (MediaProjection), membaca teks (OCR),
 * menerjemahkan on-device (ML Kit) lalu menampilkannya sebagai overlay.
 */
class ScreenTranslateService : Service() {

    companion object {
        const val ACTION_START = "com.iks.translate.START"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        const val EXTRA_SRC = "src"
        const val EXTRA_TGT = "tgt"
        private const val ACTION_STOP = "com.iks.translate.STOP"
        private const val CHANNEL_ID = "iks_translate"
        private const val NOTIF_ID = 1
        private const val AUTO_INTERVAL_MS = 3000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private val lock = Any()

    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var heldImage: Image? = null
    private var capW = 0
    private var capH = 0

    private var translator: Translator? = null
    private var recognizer: TextRecognizer? = null
    private val cache = HashMap<String, String>()

    private var overlay: TranslationOverlayView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var control: View? = null
    private var autoLabel: TextView? = null

    private var autoJob: Job? = null
    private var auto = false
    private var busy = false
    private var started = false
    private var destroyed = false

    private val baseOverlayFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        started = true

        // Wajib dipanggil sebelum getMediaProjection (Android 14+).
        startAsForeground()

        val src = Languages.byCode(intent?.getStringExtra(EXTRA_SRC))
        val tgt = Languages.byCode(intent?.getStringExtra(EXTRA_TGT))
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src.code)
                .setTargetLanguage(tgt.code)
                .build()
        )
        recognizer = Languages.recognizer(src.script)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(resultCode, data)?.also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    if (!destroyed) stopSelf()
                }
            }, handler)
        }
        if (projection == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(WindowManager::class.java)
        addOverlay()
        addControl()
        return START_NOT_STICKY
    }

    // ---------- Notifikasi ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenTranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .addAction(0, getString(R.string.stop), stopIntent)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notif, type)
    }

    // ---------- UI overlay ----------

    private fun addOverlay() {
        val view = TranslationOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseOverlayFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        // Ketuk hasil terjemahan untuk menutupnya (mode manual).
        view.setOnClickListener {
            view.items = emptyList()
            updateOverlayTouchable()
        }
        wm.addView(view, params)
        overlay = view
        overlayParams = params
    }

    private fun updateOverlayTouchable() {
        val view = overlay ?: return
        val params = overlayParams ?: return
        val touchable = !auto && view.items.isNotEmpty()
        params.flags = if (touchable) baseOverlayFlags
        else baseOverlayFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(view, params)
    }

    private fun addControl() {
        val d = resources.displayMetrics.density
        fun label(text: String) = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
        }

        val handle = label("⠿")
        val btnTranslate = label(getString(R.string.btn_translate)).apply {
            setOnClickListener { scope.launch { translateScreen(manual = true) } }
        }
        val btnAuto = label(getString(R.string.auto_off)).apply {
            setOnClickListener { toggleAuto() }
        }
        val btnClose = label("✕").apply { setOnClickListener { stopSelf() } }
        autoLabel = btnAuto

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                setColor(0xEE222B36.toInt())
                cornerRadius = 28 * d
            }
            addView(handle)
            addView(btnTranslate)
            addView(btnAuto)
            addView(btnClose)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (200 * d).toInt()
        }

        // Geser panel lewat ikon ⠿
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(row, params)
                }
            }
            true
        }

        wm.addView(row, params)
        control = row
    }

    private fun toggleAuto() {
        auto = !auto
        autoLabel?.apply {
            text = getString(if (auto) R.string.auto_on else R.string.auto_off)
            setTextColor(if (auto) 0xFF7CFFB2.toInt() else Color.WHITE)
        }
        autoJob?.cancel()
        if (auto) {
            autoJob = scope.launch {
                while (isActive) {
                    translateScreen(manual = false)
                    delay(AUTO_INTERVAL_MS)
                }
            }
        } else {
            overlay?.items = emptyList()
        }
        updateOverlayTouchable()
    }

    // ---------- Tangkap layar ----------

    private fun currentScreenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun ensureCapture() {
        val (w, h) = currentScreenSize()
        if (reader != null && w == capW && h == capH) return
        val dpi = resources.displayMetrics.densityDpi

        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        newReader.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
            synchronized(lock) {
                heldImage?.close()
                heldImage = img
            }
        }, handler)

        val vd = virtualDisplay
        if (vd == null) {
            virtualDisplay = projection?.createVirtualDisplay(
                "IKSTranslate", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, handler
            )
        } else {
            vd.resize(w, h, dpi)
            vd.surface = newReader.surface
        }
        synchronized(lock) {
            heldImage?.close()
            heldImage = null
        }
        reader?.close()
        reader = newReader
        capW = w
        capH = h
    }

    private fun imageToBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        plane.buffer.rewind()
        val rowPadding = plane.rowStride - plane.pixelStride * img.width
        val full = Bitmap.createBitmap(
            img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888
        )
        full.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return full
        val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        full.recycle()
        return cropped
    }

    private suspend fun grabFrame(): Bitmap? {
        repeat(10) {
            val bmp = synchronized(lock) { heldImage?.let { imageToBitmap(it) } }
            if (bmp != null) return bmp
            delay(100)
        }
        return null
    }

    private fun controlRect(): Rect {
        val v = control ?: return Rect()
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val pad = (8 * resources.displayMetrics.density).toInt()
        return Rect(loc[0] - pad, loc[1] - pad, loc[0] + v.width + pad, loc[1] + v.height + pad)
    }

    // ---------- OCR + terjemah ----------

    private suspend fun translateScreen(manual: Boolean) {
        if (busy || destroyed) return
        busy = true
        try {
            // Sembunyikan hasil sebelumnya agar tidak ikut terbaca OCR.
            overlay?.visibility = View.INVISIBLE
            ensureCapture()
            delay(200)
            val bitmap = grabFrame()
            if (bitmap == null) {
                if (manual) toast(getString(R.string.err_capture))
                return
            }
            val result = recognizer!!.process(InputImage.fromBitmap(bitmap, 0)).await()
            bitmap.recycle()

            val avoid = controlRect()
            val items = ArrayList<TranslationOverlayView.Item>()
            for (block in result.textBlocks) {
                val rect = block.boundingBox ?: continue
                if (Rect.intersects(rect, avoid)) continue
                val source = block.text.replace('\n', ' ').trim()
                if (source.length < 2) continue
                val translated = cache[source]
                    ?: translator!!.translate(source).await().also { cache[source] = it }
                if (translated.isNotBlank()) items.add(TranslationOverlayView.Item(rect, translated))
            }
            if (items.isEmpty() && manual) toast(getString(R.string.no_text))
            overlay?.items = items
            updateOverlayTouchable()
        } catch (e: Exception) {
            if (manual) toast(getString(R.string.err_generic, e.message ?: ""))
        } finally {
            overlay?.visibility = View.VISIBLE
            busy = false
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Bersih-bersih ----------

    override fun onDestroy() {
        destroyed = true
        autoJob?.cancel()
        scope.cancel()
        runCatching { overlay?.let { wm.removeView(it) } }
        runCatching { control?.let { wm.removeView(it) } }
        runCatching { virtualDisplay?.release() }
        synchronized(lock) {
            runCatching { heldImage?.close() }
            heldImage = null
        }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        runCatching { translator?.close() }
        runCatching { recognizer?.close() }
        super.onDestroy()
    }
}
